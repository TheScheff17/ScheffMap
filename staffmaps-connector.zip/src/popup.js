/**
 * StaffMaps Connector - Popup Script
 */

const btDot       = document.getElementById('btDot');
const btStatus    = document.getElementById('btStatus');
const deviceName  = document.getElementById('deviceName');
const btnConnect  = document.getElementById('btnConnect');
const btnDisconn  = document.getElementById('btnDisconnect');
const bleStatus   = document.getElementById('bleStatus');
const versionEl   = document.getElementById('version');

// Set version
const manifest = chrome.runtime.getManifest();
versionEl.textContent = manifest.version;

// ── State Rendering ──────────────────────────────────────────────────────────

function setConnected(deviceNameText) {
  btDot.className     = 'status-dot connected';
  btStatus.textContent = 'Connected';
  deviceName.textContent = deviceNameText || 'StaffMaps Device';
  deviceName.classList.add('visible');
  btnConnect.disabled  = true;
  btnDisconn.disabled  = false;
  bleStatus.textContent = 'Active';
  bleStatus.classList.add('active');
}

function setDisconnected() {
  btDot.className      = 'status-dot';
  btStatus.textContent = 'Disconnected';
  deviceName.classList.remove('visible');
  btnConnect.disabled  = false;
  btnDisconn.disabled  = true;
  bleStatus.textContent = 'Inactive';
  bleStatus.classList.remove('active');
}

function setConnecting() {
  btDot.className      = 'status-dot connecting';
  btStatus.textContent = 'Connecting…';
  btnConnect.disabled  = true;
  btnDisconn.disabled  = true;
}

// ── Init ─────────────────────────────────────────────────────────────────────

chrome.runtime.sendMessage({ type: 'SM_GET_STATUS' }, (response) => {
  if (chrome.runtime.lastError) return;
  if (response?.connected) {
    setConnected(response.deviceName);
  } else {
    setDisconnected();
  }
});

// ── Actions ──────────────────────────────────────────────────────────────────

btnConnect.addEventListener('click', () => {
  setConnecting();
  // Find active StaffMaps tab and trigger BT request there (needs user gesture in page)
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'SM_BT_CONNECT' });
  });
});

btnDisconn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'SM_BT_DISCONNECT' });
  setDisconnected();
});

// ── Background Messages ──────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {
    case 'SM_BT_CONNECTED':
      setConnected(message.device?.name);
      break;
    case 'SM_BT_DISCONNECTED':
      setDisconnected();
      break;
    case 'SM_BT_ERROR':
      setDisconnected();
      btStatus.textContent = 'Error';
      break;
  }
});
