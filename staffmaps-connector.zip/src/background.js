/**
 * StaffMaps Connector - Background Service Worker
 * Manages Bluetooth GATT connection to iOS host device
 * Bridges BLE packets to/from StaffMaps web app via content script
 */

// ── Constants ────────────────────────────────────────────────────────────────

const STAFFMAPS_SERVICE_UUID     = '6e400001-b5b3-f393-e0a9-e50e24dcca9e';
const STAFFMAPS_TX_CHAR_UUID     = '6e400002-b5b3-f393-e0a9-e50e24dcca9e'; // write to device
const STAFFMAPS_RX_CHAR_UUID     = '6e400003-b5b3-f393-e0a9-e50e24dcca9e'; // notify from device

const MSG_TYPES = {
  // Extension → Page
  BT_CONNECTED:     'SM_BT_CONNECTED',
  BT_DISCONNECTED:  'SM_BT_DISCONNECTED',
  BT_DATA:          'SM_BT_DATA',
  BT_ERROR:         'SM_BT_ERROR',
  STATUS:           'SM_STATUS',
  // Page → Extension
  BT_CONNECT:       'SM_BT_CONNECT',
  BT_DISCONNECT:    'SM_BT_DISCONNECT',
  BT_SEND:          'SM_BT_SEND',
  GET_STATUS:       'SM_GET_STATUS',
};

// ── State ────────────────────────────────────────────────────────────────────

let btDevice    = null;
let btServer    = null;
let txChar      = null;   // write
let rxChar      = null;   // notify
let activeTabId = null;
let connected   = false;

// ── Helpers ──────────────────────────────────────────────────────────────────

function sendToTab(tabId, message) {
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, message).catch(() => {});
}

function broadcastToAllStaffMapsTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && (tab.url.includes('github.io') || tab.url.includes('localhost'))) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      }
    });
  });
}

function updateBadge(isConnected) {
  chrome.action.setBadgeText({ text: isConnected ? 'ON' : '' });
  chrome.action.setBadgeBackgroundColor({ color: isConnected ? '#2d6a4f' : '#888' });
}

// ── Bluetooth ────────────────────────────────────────────────────────────────

async function connectBluetooth(tabId) {
  activeTabId = tabId;

  try {
    // Request device - must be called from user gesture context via offscreen or tab
    // Web Bluetooth in service workers requires offscreen document in MV3
    // We delegate the actual BT request to the content script and receive the result
    sendToTab(tabId, { type: MSG_TYPES.STATUS, status: 'requesting' });
  } catch (err) {
    sendToTab(tabId, { type: MSG_TYPES.BT_ERROR, error: err.message });
  }
}

async function handleBluetoothGranted(tabId, deviceInfo) {
  // Called after content script completes BT device selection
  // Content script holds the actual BT device reference (MV3 limitation)
  activeTabId = tabId;
  connected = true;
  updateBadge(true);
  broadcastToAllStaffMapsTabs({
    type: MSG_TYPES.BT_CONNECTED,
    device: deviceInfo
  });
}

function handleBluetoothDisconnected() {
  connected = false;
  btDevice = null;
  btServer = null;
  txChar = null;
  rxChar = null;
  updateBadge(false);
  broadcastToAllStaffMapsTabs({ type: MSG_TYPES.BT_DISCONNECTED });
}

// ── Message Router ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  switch (message.type) {

    case MSG_TYPES.GET_STATUS:
      sendResponse({ connected, deviceName: btDevice?.name || null });
      break;

    case MSG_TYPES.BT_CONNECT:
      connectBluetooth(tabId);
      sendResponse({ ok: true });
      break;

    case MSG_TYPES.BT_DISCONNECT:
      handleBluetoothDisconnected();
      sendResponse({ ok: true });
      break;

    case 'SM_BT_GRANTED':
      handleBluetoothGranted(tabId, message.deviceInfo);
      sendResponse({ ok: true });
      break;

    case 'SM_BT_FAILED':
      sendToTab(tabId, { type: MSG_TYPES.BT_ERROR, error: message.error });
      sendResponse({ ok: true });
      break;

    case MSG_TYPES.BT_SEND:
      // Forward send request to the content script that holds BT device
      if (activeTabId) {
        sendToTab(activeTabId, { type: 'SM_BT_WRITE', payload: message.payload });
      }
      sendResponse({ ok: true });
      break;

    case 'SM_BT_RECEIVED':
      // Data received from BLE device, forward to all StaffMaps tabs
      broadcastToAllStaffMapsTabs({
        type: MSG_TYPES.BT_DATA,
        payload: message.payload
      });
      sendResponse({ ok: true });
      break;
  }

  return true; // keep channel open for async
});

// ── Install / Startup ────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  console.log('[StaffMaps Connector] Installed');
  updateBadge(false);
});

chrome.runtime.onStartup.addListener(() => {
  updateBadge(false);
});
