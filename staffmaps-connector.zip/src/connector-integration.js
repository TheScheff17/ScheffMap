/**
 * StaffMaps Connector Integration
 * Drop this into your StaffMaps web app.
 *
 * Detects the Chrome extension and exposes a clean API for Bluetooth P2P.
 * Falls back gracefully to WebRTC when extension is not present.
 *
 * Usage:
 *   import { StaffMapsConnector } from './connector-integration.js';
 *
 *   const connector = new StaffMapsConnector();
 *
 *   connector.on('connected', ({ deviceName }) => { ... });
 *   connector.on('data', ({ payload }) => { ... });
 *   connector.on('disconnected', () => { ... });
 *
 *   connector.connect();       // triggers BT device picker
 *   connector.send(payload);   // send string or Uint8Array
 *   connector.disconnect();
 */

export class StaffMapsConnector extends EventTarget {

  constructor() {
    super();
    this._extensionPresent = false;
    this._connected        = false;
    this._deviceName       = null;
    this._init();
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  get extensionPresent() { return this._extensionPresent; }
  get connected()        { return this._connected; }
  get deviceName()       { return this._deviceName; }

  /** Trigger Bluetooth device picker (must be called from user gesture) */
  connect() {
    if (!this._extensionPresent) {
      console.warn('[StaffMaps] Extension not present — cannot use Bluetooth transport');
      this._emit('extension-missing');
      return;
    }
    window.dispatchEvent(new CustomEvent('staffmaps:connector:connect'));
  }

  /** Disconnect from current BLE device */
  disconnect() {
    window.dispatchEvent(new CustomEvent('staffmaps:connector:disconnect'));
  }

  /**
   * Send data over Bluetooth
   * @param {string|Uint8Array} payload
   */
  send(payload) {
    if (!this._connected) return false;
    window.dispatchEvent(new CustomEvent('staffmaps:connector:send', {
      detail: { payload }
    }));
    return true;
  }

  /**
   * Send a structured StaffMaps sync packet
   * @param {string} type  - packet type e.g. 'unit_pos', 'status', 'phase'
   * @param {object} data  - payload object (will be JSON serialized + compressed)
   */
  sendPacket(type, data) {
    const packet = JSON.stringify({ t: type, d: data, ts: Date.now() });
    return this.send(packet);
  }

  /** Subscribe to connector events */
  on(event, handler) {
    this.addEventListener(event, (e) => handler(e.detail));
    return this;
  }

  /** Get current status */
  status() {
    return new Promise((resolve) => {
      if (!this._extensionPresent) {
        resolve({ extensionPresent: false, connected: false });
        return;
      }
      window.dispatchEvent(new CustomEvent('staffmaps:connector:status'));
      const handler = (e) => {
        window.removeEventListener('staffmaps:connector:status:response', handler);
        resolve(e.detail);
      };
      window.addEventListener('staffmaps:connector:status:response', handler);
      setTimeout(() => resolve({ extensionPresent: true, connected: this._connected }), 500);
    });
  }

  // ── Private ────────────────────────────────────────────────────────────────

  _init() {
    // Listen for extension ready signal
    window.addEventListener('staffmaps:connector:ready', (e) => {
      this._extensionPresent = true;
      console.log(`[StaffMaps] Connector extension v${e.detail.version} detected`);
      this._emit('extension-ready', e.detail);
    });

    // BLE connection events
    window.addEventListener('staffmaps:bt:connected', (e) => {
      this._connected  = true;
      this._deviceName = e.detail?.deviceName || 'StaffMaps Device';
      this._emit('connected', { deviceName: this._deviceName });
    });

    window.addEventListener('staffmaps:bt:disconnected', () => {
      this._connected  = false;
      this._deviceName = null;
      this._emit('disconnected');
    });

    window.addEventListener('staffmaps:bt:error', (e) => {
      this._emit('error', e.detail);
    });

    // Incoming data from BLE
    window.addEventListener('staffmaps:bt:data', (e) => {
      const raw = e.detail?.payload;
      if (!raw) return;

      let parsed = null;
      try { parsed = JSON.parse(raw); } catch (_) { /* raw string */ }

      this._emit('data', { payload: raw, parsed });

      // Convenience: emit typed packet events
      if (parsed?.t) {
        this._emit(`packet:${parsed.t}`, parsed.d);
      }
    });

    // Check if extension is already present (already fired before listener attached)
    // Small delay to allow content script to fire its ready event
    setTimeout(() => {
      if (!this._extensionPresent) {
        window.dispatchEvent(new CustomEvent('staffmaps:connector:status'));
        window.addEventListener('staffmaps:connector:status:response', (e) => {
          if (e.detail?.extensionPresent) {
            this._extensionPresent = true;
            this._connected        = e.detail.connected;
            this._deviceName       = e.detail.deviceName;
            this._emit('extension-ready', {});
          }
        }, { once: true });
      }
    }, 100);
  }

  _emit(event, detail = {}) {
    this.dispatchEvent(new CustomEvent(event, { detail }));
  }
}

// ── Packet Types ─────────────────────────────────────────────────────────────
// Standardized compact packet schema for LoRa-friendly payloads

export const PacketType = {
  UNIT_POS:    'up',   // unit position update
  UNIT_STATUS: 'us',   // unit status change
  PHASE:       'ph',   // phase change
  REPORT:      'rp',   // SALUTE/SITREP report
  CHAT:        'ch',   // short text message
  SYNC_REQ:    'sr',   // request full sync
  SYNC_ACK:    'sa',   // acknowledge sync
  PING:        'pg',   // keepalive
};

/**
 * Build a compact unit position packet
 * @param {string} unitId
 * @param {number} lat
 * @param {number} lng
 * @param {string} [status]
 */
export function buildUnitPosPacket(unitId, lat, lng, status = '') {
  return {
    id:  unitId,
    la:  parseFloat(lat.toFixed(5)),
    lo:  parseFloat(lng.toFixed(5)),
    st:  status
  };
}
