/**
 * StaffMaps Connector - Content Script
 * Injected into StaffMaps web app page.
 * 
 * Responsibilities:
 *  1. Inject the StaffMaps bridge API into the page (window.staffmapsConnector)
 *  2. Handle Web Bluetooth requests (must run in page context for user gesture)
 *  3. Maintain BLE GATT connection and relay packets to/from background
 *  4. Relay messages between page ↔ background service worker
 */

// ── Constants ────────────────────────────────────────────────────────────────

const STAFFMAPS_SERVICE_UUID = '6e400001-b5b3-f393-e0a9-e50e24dcca9e';
const TX_CHAR_UUID           = '6e400002-b5b3-f393-e0a9-e50e24dcca9e'; // PC writes to iOS
const RX_CHAR_UUID           = '6e400003-b5b3-f393-e0a9-e50e24dcca9e'; // iOS notifies PC

// ── State ────────────────────────────────────────────────────────────────────

let btDevice  = null;
let btServer  = null;
let txChar    = null;
let rxChar    = null;
let connected = false;

const encoder = new TextEncoder();
const decoder = new TextDecoder();

// ── Bluetooth ────────────────────────────────────────────────────────────────

async function requestBluetoothDevice() {
  try {
    btDevice = await navigator.bluetooth.requestDevice({
      filters: [{ name: 'StaffMaps' }, { namePrefix: 'SM-' }],
      optionalServices: [STAFFMAPS_SERVICE_UUID]
    });

    btDevice.addEventListener('gattserverdisconnected', onDisconnected);

    btServer = await btDevice.gatt.connect();

    const service = await btServer.getPrimaryService(STAFFMAPS_SERVICE_UUID);
    txChar        = await service.getCharacteristic(TX_CHAR_UUID);
    rxChar        = await service.getCharacteristic(RX_CHAR_UUID);

    await rxChar.startNotifications();
    rxChar.addEventListener('characteristicvaluechanged', onDataReceived);

    connected = true;

    // Tell background we succeeded
    chrome.runtime.sendMessage({
      type: 'SM_BT_GRANTED',
      deviceInfo: { name: btDevice.name, id: btDevice.id }
    });

    // Tell page
    window.dispatchEvent(new CustomEvent('staffmaps:bt:connected', {
      detail: { deviceName: btDevice.name }
    }));

  } catch (err) {
    chrome.runtime.sendMessage({ type: 'SM_BT_FAILED', error: err.message });
    window.dispatchEvent(new CustomEvent('staffmaps:bt:error', {
      detail: { error: err.message }
    }));
  }
}

function onDisconnected() {
  connected = false;
  btDevice  = null;
  btServer  = null;
  txChar    = null;
  rxChar    = null;
  chrome.runtime.sendMessage({ type: 'SM_BT_DISCONNECTED' });
  window.dispatchEvent(new CustomEvent('staffmaps:bt:disconnected'));
}

function onDataReceived(event) {
  const raw     = event.target.value;
  const payload = decoder.decode(raw);

  // Forward to background for broadcast to other tabs
  chrome.runtime.sendMessage({ type: 'SM_BT_RECEIVED', payload });

  // Forward to page
  window.dispatchEvent(new CustomEvent('staffmaps:bt:data', { detail: { payload } }));
}

async function sendData(payload) {
  if (!txChar || !connected) return false;
  try {
    const data = typeof payload === 'string' ? encoder.encode(payload) : payload;
    // BLE max write without response is typically 512 bytes; chunk if needed
    const CHUNK_SIZE = 512;
    for (let i = 0; i < data.length; i += CHUNK_SIZE) {
      await txChar.writeValueWithoutResponse(data.slice(i, i + CHUNK_SIZE));
    }
    return true;
  } catch (err) {
    console.warn('[StaffMaps Connector] BLE write error:', err);
    return false;
  }
}

async function disconnectBluetooth() {
  if (btDevice?.gatt?.connected) {
    btDevice.gatt.disconnect();
  }
  onDisconnected();
}

// ── Background Message Handler ───────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {

    case 'SM_BT_CONNECT':
      // Must be triggered by user gesture - relay via page event
      window.dispatchEvent(new CustomEvent('staffmaps:bt:request'));
      break;

    case 'SM_BT_WRITE':
      sendData(message.payload);
      break;

    case 'SM_BT_DISCONNECTED':
      disconnectBluetooth();
      break;

    case 'SM_BT_DATA':
      // Data from another tab's BLE session, forward to this page
      window.dispatchEvent(new CustomEvent('staffmaps:bt:data', {
        detail: { payload: message.payload }
      }));
      break;

    case 'SM_BT_CONNECTED':
      window.dispatchEvent(new CustomEvent('staffmaps:bt:connected', {
        detail: message.device
      }));
      break;

    case 'SM_BT_DISCONNECTED':
      window.dispatchEvent(new CustomEvent('staffmaps:bt:disconnected'));
      break;
  }
});

// ── Page → Extension Bridge ──────────────────────────────────────────────────
// StaffMaps web app uses window events to communicate with the extension

window.addEventListener('staffmaps:connector:connect', () => {
  requestBluetoothDevice();
});

window.addEventListener('staffmaps:connector:disconnect', () => {
  disconnectBluetooth();
});

window.addEventListener('staffmaps:connector:send', (e) => {
  sendData(e.detail?.payload);
});

window.addEventListener('staffmaps:connector:status', () => {
  window.dispatchEvent(new CustomEvent('staffmaps:connector:status:response', {
    detail: {
      connected,
      extensionPresent: true,
      deviceName: btDevice?.name || null
    }
  }));
});

// ── Signal Extension Presence to Page ───────────────────────────────────────

window.dispatchEvent(new CustomEvent('staffmaps:connector:ready', {
  detail: { version: chrome.runtime.getManifest().version }
}));

console.log('[StaffMaps Connector] Content script active');
