# StaffMaps Connector — Chrome Extension

Enables Bluetooth mesh connectivity for StaffMaps on Windows/Mac laptops, bridging them into a session with iOS devices (iPad/iPhone) without any network infrastructure.

## Architecture

```
iPad (StaffMaps native)
    ↕ Bluetooth LE (GATT)
PC Chrome (StaffMaps web app)
    ↕ Web Bluetooth API
Chrome Extension (this)
    ↕ Content Script ↔ Background Service Worker
StaffMaps Web App (connector-integration.js)
```

## Transport Priority

The StaffMaps app automatically selects the best available transport:

| Scenario | Transport |
|---|---|
| Infrastructure available | WebRTC + TURN |
| Local network, mixed devices | WebRTC local |
| Local network, Apple only | MultipeerConnectivity |
| No infrastructure, PC present | Bluetooth LE (this extension) |
| Degraded / denied | LoRa via Meshtastic |

## Installation (Development)

1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select this folder

## Installation (Production)

Publish to Chrome Web Store. Users visit StaffMaps GitHub Pages and are prompted to install.

## BLE GATT Profile

| Attribute | UUID |
|---|---|
| Service | `6e400001-b5b3-f393-e0a9-e50e24dcca9e` |
| TX (PC → iOS) | `6e400002-b5b3-f393-e0a9-e50e24dcca9e` |
| RX (iOS → PC, notify) | `6e400003-b5b3-f393-e0a9-e50e24dcca9e` |

These UUIDs mirror the Nordic UART Service (NUS) convention, compatible with most BLE tooling.

## Web App Integration

```js
import { StaffMapsConnector, PacketType, buildUnitPosPacket } from './connector-integration.js';

const connector = new StaffMapsConnector();

connector
  .on('extension-ready', () => {
    // Show BT connect option in UI
  })
  .on('connected', ({ deviceName }) => {
    console.log('BLE connected to', deviceName);
  })
  .on('data', ({ parsed }) => {
    // Handle incoming sync packet
  })
  .on('disconnected', () => {
    // Fall back to WebRTC or notify user
  });

// Send a unit position (called on timed sync interval)
connector.sendPacket(PacketType.UNIT_POS, buildUnitPosPacket('1-1-A', 38.123, -77.456, 'REDCON1'));
```

## Packet Schema

Packets are compact JSON to minimize BLE payload size. All field names are abbreviated.

```json
{ "t": "up", "d": { "id": "1-1-A", "la": 38.123, "lo": -77.456, "st": "REDCON1" }, "ts": 1700000000000 }
```

### Packet Types

| Type | Code | Use |
|---|---|---|
| Unit Position | `up` | Timed position sync |
| Unit Status | `us` | Status change |
| Phase Change | `ph` | COA phase push |
| Report | `rp` | SALUTE/SITREP |
| Chat | `ch` | Short message |
| Sync Request | `sr` | Request full state |
| Sync Ack | `sa` | Confirm sync |
| Ping | `pg` | Keepalive |

## EMCON / Sync Intervals

Sync interval is set by the session commander in the Operations panel. Extension respects whatever cadence the app implements — it is a passive transport layer only.

## Requirements

- Chrome 85+ (Web Bluetooth support)
- Windows 10+ or macOS 10.15+ with Bluetooth LE hardware
- iOS StaffMaps native app advertising the GATT service
